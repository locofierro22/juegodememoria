//: Playground - noun: a place where people can play

import UIKit

var numeros = 0...100
for n in numeros{
    switch n {
    case n % 2 == 0 && n % 5 != 0 :
      print("\(n) Par!!!")
    case n % 2 != 0 && n % 5 != 0 :
       print("\(n) Impar!!!")
    case n % 5 == 0 :
        print("\(n) Bingo!!!")
    case n >= 30 && n <= 40 {
        print("\(n) Viva Switch!!!")
        }
}